package com_example.sales_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
